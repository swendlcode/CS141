public class Avarage {
    public static void main(String[] args) {
        int StudentOne, StudentTwo, StudentThree;
        double Avarage;
        StudentOne = 85;
        StudentTwo = 86;
        StudentThree = 92;
        Avarage = (StudentOne + StudentTwo + StudentThree) / 3.0;

        System.out.println("Student One: " + StudentOne);
        System.out.println("Student Two: " + StudentTwo);
        System.out.println("Student Three: " + StudentThree);
        System.out.println("Avarage: " + Avarage);
    }
}